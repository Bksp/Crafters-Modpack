<div align="center">

![](./some_mods_en_latino_ba.png)

</div>

I have translated some mods, I have corrected some translations.
Although I uploaded them to their respective Githubs, they probably don't have the support for old versions.
So I approved this pack. which I intend to update over time.
----------------------------------------------------------------------------------------

He traducido algunos mods, he corregido algunas traducciones.
Si bien las subí a sus respectivos Githubs, probablemente no tengan el soporte para versiones antiguas..
Así que homologué este pack. que pretendo ir actualizando con el tiempo.



Supported Mods are:

```
abundant_atmosphere
additionaladditions
advancednetherite
alexsmobs
another_furniture
aquamirae
biomesoplenty
boatload
botania 97%
bushierflowers
capybaramod
collectorsreap
compatoplenty
corpse
delightful
domesticationinnovation
dramaticdoors
everycomp
farmersdelight
farmersrespite
furnish
galosphere
handcrafted
harvestseason
incubation
ironbows
multibeds
obscure_api
parcool
patchouli
some_assembly_required
storagedrawers 80%
waystones
weaponmaster
wildberries
windswept
woodworks
```
