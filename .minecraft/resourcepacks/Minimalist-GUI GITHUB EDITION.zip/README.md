<div align="center">

![](.demos/showcase.png)
![](.demos/BASE.png)
![](.demos/GUI.png)
![](.demos/recipes.png)
![](.demos/storage_drawers.png)
![](.demos/waystones.png)
![](.demos/mods_comp_quiver.png)
![](/.demos/Menu.png)

# A minimalist Resource Pack for minecraft is in development. 
 (but it is already functional)

</div>

## Mods Compatibility
+ appleskin
+ farmersdelight
+ inventoryhud
+ inventoryprofilesnext
+ parcool
+ supplementaries (quiver)
+ xaeros minimap

<div align="center">

![](./pack.png)

</div>
