### Fusion Connected Glass 1.0.1
- Account for 1.21.9 pack.mcmeta format changes

### Fusion Connected Glass 1.0.0
- Initial release of Fusion Connected Glass
